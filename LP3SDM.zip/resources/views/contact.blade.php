@extends('layout/main')

@section('container')
  <h1>
    Contact Us
  </h1>
@endsection