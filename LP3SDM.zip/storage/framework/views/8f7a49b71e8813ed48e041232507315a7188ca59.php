

<?php $__env->startSection('container'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-5 mt-5 mb-5">
            <main class="form-register">
                <h1 class="h3 f2-normal text-center">Unggah Sertifikat</h1>
                <div class="text-center">
                    <i class="bi bi-card-heading" style="font-size:150px"></i>
                </div>
                <form action="<?php echo e(route('post-sertifikat')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-floating">
                        <select class="form-select" id="floatingSelect" name="pelatihan_id" required>
                            <option selected>Pilih Nama Pelatihan</option>
                            <?php $__currentLoopData = $pelatihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($post->id); ?>"><?php echo e($post->nama_pelatihan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="floatingSelect">Nama Pelatihan</label>
                    </div>

                    <div class="form-floating">
                        <select class="form-select" id="floatingSelect" name="peserta_id" required>
                            <option selected>Pilih Nama Peserta</option>
                            <?php $__currentLoopData = $postData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($post->id); ?>"><?php echo e($post->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="floatingSelect">Nama Peserta</label>
                    </div>

                    <br>

                    <div class="form-group">
                        <label for="">Foto Sertifikat</label>
                        <input type="file" class="form-control-file" name="foto_sertifikat" required>
                        <?php $__errorArgs = ['foto_sertifikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button class="w-100 btn btn-lg btn-success mt-3" type="submit">Unggah Sertifikat</button>
                </form>
            </main>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\faris\LP3SDM\resources\views//sertifikat.blade.php ENDPATH**/ ?>