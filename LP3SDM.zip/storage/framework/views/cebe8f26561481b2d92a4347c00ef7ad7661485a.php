

<?php $__env->startSection('container'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Akun</h1>

        </div>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div align="right">
            <a href="<?php echo e(route('akun.trash')); ?>" class="btn btn-danger"><span class="" data-feather="power"
                style="margin-bottom : 2px"></span> Akun Nonaktif</a>
            <a href="<?php echo e(route('tambah-peserta')); ?>" class="btn btn-success"><span class="" data-feather="plus"
                    style="margin-bottom : 2px"></span> Tambah Admin</a>
        </div>
        <br>
        <div class="table-responsive">
            <table class="table table-striped" width="100%" cellspacing="0" id="dataPeserta">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">NIP</th>
                        <th scope="col">Level</th>
                        <th scope="col">Email</th>
                        <th scope="col">Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($users->name); ?></td>
                            <td><?php echo e($users->nip); ?></td>
                            <td><?php echo e($users->level); ?></td>
                            <td><?php echo e($users->email); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit-datapeserta', $users->id)); ?>" class="badge bg-warning"><span
                                        data-feather="edit"></span></a>
                              
                                <a href="<?php echo e(route('delete-datapeserta', $users->id)); ?>" class="badge bg-danger"
                                    onclick="return confirm('Apakah User Ini Ingin Di Nonaktifkan?')"><span
                                        data-feather="power"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('#dataPeserta').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout/main-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\faris\LP3SDM\resources\views/data-peserta.blade.php ENDPATH**/ ?>