

<?php $__env->startSection('container'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Selamat Datang, <?php echo e(auth()->user()->name); ?></h1>

        </div>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div align="right">
            <a href="<?php echo e(route('jadwal')); ?>" class="btn btn-danger"><span class=""
                    data-feather="corner-up-left" style="margin-bottom : 2px"></span> Back</a>
        </div>
        <br>
        <div class="table-responsive">
            <table class="table table-striped table-sm" width="100%" cellspacing="0" id="dataJadwal">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama Pelatihan</th>
                        <th scope="col">Narasumber</th>
                        <th scope="col">Tempat</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Hari</th>
                        <th scope="col">Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($post->nama_pelatihan); ?></td>
                            <td><?php echo e($post->narasumber); ?></td>
                            <td><?php echo e($post->tempat); ?></td>
                            <td><?php echo e($post->tanggal); ?></td>
                            <td><?php echo e($post->hari); ?></td>
                            <td>
                                <a href="<?php echo e(route('jadwal.restore', $post->id)); ?>" class="badge bg-success"
                                    onclick="return confirm('Apakah Jadwal Ingin Di Aktifkan Lagi?')"><span
                                        data-feather="power"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('#dataBlog').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout/main-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\faris\LP3SDM\resources\views/trash-jadwal.blade.php ENDPATH**/ ?>