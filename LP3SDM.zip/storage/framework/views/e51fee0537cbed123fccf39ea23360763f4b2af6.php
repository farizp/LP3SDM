

<?php $__env->startSection('container'); ?>
    <div>
        <h2 class="text-center">
            Tentang<br>Lembaga Penelitian dan Evaluasi Indonesia
        </h2><br>

        <p class="text-center">
            "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iste voluptatem cum ullam nostrum provident suscipit modi ea eos quas quod enim ut, a aliquid, repellendus quo at, dolorem ex quam in explicabo sunt est. Dolorum, dolores aliquid porro non officiis itaque sed eligendi neque? Quia nisi quos odio dolores fugit. Blanditiis vitae fugit corrupti itaque autem, eius libero molestias, vel eum cumque nesciunt consequuntur quasi et nam explicabo repudiandae sed odit dolores tenetur, cupiditate aliquam ad ipsum aperiam fugiat. Odit repellendus, quae, sint ducimus quos tempore dicta ab, voluptatum asperiores consequatur possimus et consequuntur porro doloribus natus sunt temporibus atque!"
        </p>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\faris\LP3SDM\resources\views/about.blade.php ENDPATH**/ ?>