

<?php $__env->startSection('container'); ?>

    <div class="container">
        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row row-cols-1 row-cols-md-3 g-4 mt-4">
            <div class="col">
                <div class="card h-100">
                <img src="<?php echo e(asset('storage/'.$item->foto)); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                    <p class="card-text">
                        <?php echo Str::limit($item->keterangan, 200); ?> 
                    </p>
                    <a href="<?php echo e(route('show-blog', $item->id)); ?>" class="btn btn-primary">Lanjut Baca</a>
                </div>
                <div class="card-footer">
                    <small class="text-muted"><?php echo e($item->created_at->diffForHumans()); ?></small>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\faris\LP3SDM\resources\views/blog.blade.php ENDPATH**/ ?>