<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="/">LP3SDM</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">

            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?php echo e($title === 'Beranda' ? 'active' : ''); ?>" href="/">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($title === 'Tentang' ? 'active' : ''); ?>" href="/about">Tentang</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($title === 'Berita' ? 'active' : ''); ?>"
                        href="<?php echo e(route('blog-home')); ?>">Berita</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($title === 'Pendaftaran' ? 'active' : ''); ?>"
                        href="/registration">Pendaftaran</a>
                </li>
            </ul>

            <ul class="navbar-nav ms-auto">
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i> <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php if(auth()->user()->level == 'admin'): ?>
                                <li><a class="dropdown-item" href="/dashboard">Dashboard</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e(route('profile', auth()->user()->id)); ?>" class="nav-link text-dark">
                                        &nbsp; <i class="bi bi-person"></i> Sertifikat</a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <form action="/" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right"></i>
                                        Keluar</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a href="/login" class="nav-link <?php echo e($title === 'Masuk' ? 'active' : ''); ?>"
                            class="nav-link"><i class="bi bi-box-arrow-in-right"></i> Masuk</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\faris\LP3SDM\resources\views/partials/navbar.blade.php ENDPATH**/ ?>